const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
const port = 3001;

// Enable CORS for all routes
app.use(cors({
    origin: 'http://localhost:3000',
  }));

const pool = new Pool({
    'host': '13.126.193.136',
    'database': 'MorDB',
    'user': 'postgres',
    'password': 'suMZT53D2Y',
    'port': 5432,
});
// api for just fetching records from bufferaccumulation
app.get('/api/sales', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('select sum(soldqty) as sum ,sum(replenishedqty) as purchase,sum(returnqty) as return from inventory ');
      console.log("sum is ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  app.get('/api/weekly', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('SELECT EXTRACT(MONTH FROM date) AS month,SUM(soldqty) AS total_sold_qty,SUM(returnqty) AS total_eod_qty FROM inventory GROUP BY month ORDER BY month ');
      console.log("data ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  app.get('/api/bar', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('SELECT EXTRACT(MONTH FROM date) AS month,SUM(soldqty) AS total_sold_qty,SUM(replenishedqty) AS total_replenished_qty FROM inventory GROUP BY month ORDER BY month ');
      console.log("data ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  app.get('/api/monthly', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('SELECT EXTRACT(MONTH FROM date) AS month,SUM(soldqty) AS total_sold_qty,SUM(eodstockqty) AS total_eod_qty FROM inventory GROUP BY month ORDER BY month ');
      console.log("data ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  app.get('/api/purchase', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('select sum(replenishedqty) as Purchase  from inventory ');
      console.log("Purchase is ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  app.get('/api/returns', async (req, res) => {
    try {
      console.log("connecting to inventory")
      const client = await pool.connect();
      console.log("connected to postgreesql")
      const result = await client.query('select sum(returnqty) as Returns  from inventory ');
      console.log("Returns is ",result)
      const results = { 'results': (result) ? result.rows : null };
      res.json(results);
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  });
  
app.get('/api/data', async (req, res) => {
  try {
    console.log("trying to connect")
    const client = await pool.connect();
    console.log("connected to postgreesql")
    const result = await client.query('select storeid, productskuid, date, initialstockqty from inventory limit 5');
    console.log("fetching form inventory ",result)
    const results = { 'results': (result) ? result.rows : null };
    res.json(results);
    client.release();
  } catch (err) {
    console.error(err);
    res.send("Error " + err);
  }
});
// api for low quantity stocks
app.get('/api/low-stock', async (req, res) => {
    try {
        console.log("trying to buffer")
      const client = await pool.connect();
      console.log("receving")
      const result = await client.query('SELECT s.name AS storename, bac.storeid, bac.inventorycount FROM bufferaccumulationcalc bac JOIN store s ON bac.storeid = s.id WHERE zone = $1 LIMIT 3', ['RED']);
      console.log("fetching  low stock from bufferaccumualtion")
      const lowStockData = (result) ? result.rows : null;
      res.json(lowStockData);
      client.release();
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  // api for excess quantity stocks 
  app.get('/api/excess-stock', async (req, res) => {
    try {
        console.log("trying to excessstock")
      const client = await pool.connect();
      console.log("extracting excessstcok")
      const result = await client.query('SELECT s.name AS storename, bac.storeid, bac.inventorycount FROM bufferaccumulationcalc bac JOIN store s ON bac.storeid = s.id WHERE zone = $1 LIMIT 3', ['GREEN']);
      console.log("result",result)
      const lowStockData = (result) ? result.rows : null;
      res.json(lowStockData);
      client.release();
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  

app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
