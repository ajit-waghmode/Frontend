// App.js
import React from 'react';
import Data from './data';
import Low from './lowselling';
import Excess from './excess.js';
import './App.css'
import MainDash from './components/MainDash/MainDash';
import RightSide from './components/RigtSide/RightSide';
import Sidebar from './components/Sidebar';
import { Scrollbars } from 'react-custom-scrollbars';
const App = () => {
  return (
    <div className="App">
      <div className="AppGlass">
      <Sidebar/>  
      <MainDash/>
      <Scrollbars style={{ width: '100%', height: '100vh' }}>
      <RightSide/>
    </Scrollbars>
      </div>
      
      
    </div>
  );
};

export default App;
