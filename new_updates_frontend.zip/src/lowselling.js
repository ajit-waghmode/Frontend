// LowStock.js
import React, { useState, useEffect } from 'react';

import axios from 'axios';

const LowStock = () => {
  const [lowStockData, setLowStockData] = useState([]);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios('http://localhost:3001/api/low-stock');
        console.log('fetching from lowbuffer',result)
        setLowStockData(result.data);
      } catch (error) {
        console.error('Error fetching low stock data:', error);
      }
    };

    fetchData();
  }, []);
  const displayedStockData = showAll ? lowStockData : lowStockData.slice(0, 3);

  return (
    <div style={styles.container}>
      <h1>Low Quantity Stock</h1>
      <button onClick={() => setShowAll(!showAll)}>
        {showAll ? 'Show Less' : 'See All'}
      </button>
      <ul>
        {displayedStockData.map((item) => (
          <li key={item.storeid}>
            Store ID: {item.storeid} <br />
            <span style={{ fontWeight: 'bold' }}>Remaining Quantity: {item.inventorycount}</span> Packet
          </li>
        ))}
      </ul>
    </div>
  );
};

const styles = {
  container: {
    position: 'fixed',
    bottom: '10px',
    right: '10px',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    padding: '10px',
    borderRadius: '5px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
};

export default LowStock;
