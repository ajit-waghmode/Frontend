// ExcessStock.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ExcessStock = () => {
  const [excessStockData, setExcessStockData] = useState([]);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios('http://localhost:3001/api/excess-stock');
        setExcessStockData(result.data);
      } catch (error) {
        console.error('Error fetching excess stock data:', error);
      }
    };

    fetchData();
  }, []);

  const displayedStockData = showAll ? excessStockData : excessStockData.slice(0, 3);

  return (
    <div style={styles.container}>
      <h1>Excess Quantity Stock</h1>
      <button onClick={() => setShowAll(!showAll)}>
        {showAll ? 'Show Less' : 'See All'}
      </button>
      <ul>
        {displayedStockData.map((item) => (
          <li key={item.storeid}>
            Store ID: {item.storeid} <br />
            <span style={{ fontWeight: 'bold' }}>Excess Quantity: {item.inventorycount}</span> Packet
          </li>
        ))}
      </ul>
    </div>
  );
};

const styles = {
  container: {
    position: 'fixed',
    top: '10px',
    right: '10px',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    padding: '10px',
    borderRadius: '5px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
};

export default ExcessStock;
