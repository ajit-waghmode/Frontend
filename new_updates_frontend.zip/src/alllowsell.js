// LowStockAll.js
import React from 'react';

const LowStockAll = ({ lowStockData }) => {
  return (
    <div>
      <h1>All Low Quantity Stock</h1>
      <ul>
        {lowStockData.map((item) => (
          <li key={item.storeid}>
            Store ID: {item.storeid} <br />
            <span style={{ fontWeight: 'bold' }}>Remaining Quantity: {item.inventorycount}</span> Packet
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LowStockAll;
