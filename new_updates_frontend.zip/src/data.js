// DataFetchingComponent.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Data = () => {
  const [data, setData] = useState([]);
  const [totalSum, setTotalSum] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios('http://localhost:3001/api/sales');
        console.error('sum is :', result.data.results[0].sum);
        //console.error('sum is :', result.data.results[0].sum);
        setData(result.data.results);
        setTotalSum(result.data.results[0].sum);
        setData(result.data.results);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h1>Data from PostgreSQL</h1>
      <p>Total Sum: {totalSum}</p>
      <table>
        <thead>
          <tr>
            <th>Store ID</th>
            <th>Product SKU ID</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td>{item.storeid}</td>
              <td>{item.productskuid}</td>
              <td>{item.date}</td>
              <td>{item.initialstockqty}</td>
              <td>{item.eodstockqty}</td>
              <td>{item.replenishedqty}</td>
              <td>{item.soldqty}</td>

              
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Data;
