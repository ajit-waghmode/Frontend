// apiHelper.js
import axios from 'axios';

const fetchData = async (setCardsData) => {
    try {
      // Fetch data for Sales
      const result = await axios('http://localhost:3001/api/data');
      console.error('sum is :', result.data.results[0]);
    //const salesResponse = await fetch('/api/data');
    //const salesData = await salesResponse.json();
    const salesQtySum = result.data.results[0];
    console.log("coming sum is",salesQtySum);
    //const result = await axios('http://localhost:3001/api/data');
    //console.error('fetched data :', result);
  
      // Fetch data for Revenue
      //const revenueResponse = await fetch('/api/data');
      //const revenueData = await revenueResponse.json();
      //const revenueQtySum = parseInt(revenueData.results[0].sum, 10);
  
      // Update specific fields in the cardsData array
      setCardsData(prevState => prevState.map(item => {
        if (item.title === "Sales") {
          return {
            ...item,
            barValue: salesQtySum,
            value: salesQtySum.toLocaleString(),
            series: [
              {
                name: "Sales",
                data: salesQtySum,
              },
            ],
          };
        } else if (item.title === "Revenue") {
          return {
            ...item,
            barValue: salesQtySum,
            value: salesQtySum.toLocaleString(),
            series: [
              {
                name: "Revenue",
                data: salesQtySum
              },
            ],
          };
        } else if (item.title === "Profit") {
          return {
            ...item,
            barValue: salesQtySum - salesQtySum, // Adjust as per your calculation logic
            value: (salesQtySum - salesQtySum).toLocaleString(), // Adjust as per your formatting logic
            series: [
              {
                name: "Expenses",
                data: salesQtySum,
              },
            ],
          };
        } else {
          return item;
        }
      }));
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  
  export default fetchData;
  