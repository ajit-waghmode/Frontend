import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export default function BarChartComponent() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios('http://localhost:3001/api/bar');
        console.log('Raw API response:', response.data);

        // Check if response.data.results is an array
        if (Array.isArray(response.data.results)) {
          const formattedData = response.data.results.map((item) => ({
            month: `Month ${item.month}`,
            total_sold_qty: parseFloat(item.total_sold_qty),
            total_replenished_qty: parseFloat(item.total_replenished_qty),
          }));
          setData(formattedData);
        } else {
          console.error('API response does not contain an array:', response.data);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <h3>Sales & Purchase</h3>
      <BarChart
        width={500}
        height={300}
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="total_sold_qty" fill="#8884d8" />
        <Bar dataKey="total_replenished_qty" fill="#82ca9d" />
      </BarChart>
      
    </ResponsiveContainer>
  );
}
