// apiHelper.js

const fetchData = async (setCardsData) => {
    try {
      // Fetch data for Sales
      const salesResponse = await fetch('/api/data');
      const salesData = await salesResponse.json();
      const salesQtySum = parseInt(salesData.results[0].sum, 10);
  
      // Fetch data for Revenue
      const revenueResponse = await fetch('/api/data');
      const revenueData = await revenueResponse.json();
      const revenueQtySum = parseInt(revenueData.results[0].sum, 10);
  
      // Update specific fields in the cardsData array
      setCardsData(prevState => prevState.map(item => {
        if (item.title === "Sales") {
          return {
            ...item,
            barValue: salesQtySum,
            value: salesQtySum.toLocaleString(),
            series: [
              {
                name: "Sales",
                data: salesQtySum,
              },
            ],
          };
        } else if (item.title === "Revenue") {
          return {
            ...item,
            barValue: revenueQtySum,
            value: revenueQtySum.toLocaleString(),
            series: [
              {
                name: "Revenue",
                data: revenueQtySum
              },
            ],
          };
        } else if (item.title === "Profit") {
          return {
            ...item,
            barValue: salesQtySum - revenueQtySum, // Adjust as per your calculation logic
            value: (salesQtySum - revenueQtySum).toLocaleString(), // Adjust as per your formatting logic
            series: [
              {
                name: "Expenses",
                data: revenueQtySum,
              },
            ],
          };
        } else {
          return item;
        }
      }));
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  
  export default fetchData;
  