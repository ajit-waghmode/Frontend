import React from "react";
import "./Updates.css";
import { UpdatesData } from "../Data/Data";

const Updates = () => {
  return (<>
    <h3>Recommendations</h3>
    <div className="Updates">
      {UpdatesData.map((update) => {
        return (
          <div className="update">
            
            <div className="noti">
              <div  style={{marginBottom: '0.5rem'}}>
                <span>{update.name}</span>
                <br />
                <span> {update.noti}</span>
                <br />
                <span>{update.time}</span>
                <span>{update.time1}</span>
  
              </div>
              
                
            </div>
          </div>
        );
      })}
    </div>
    </>
  );
};

export default Updates;
