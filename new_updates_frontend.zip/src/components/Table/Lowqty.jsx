import * as React from "react";
import { useState, useEffect } from "react";
import axios from 'axios';
import "./Lowqty.css";

export default function BasicTable1() {
  const [data, setData] = useState([]); // Rename rows to apiRows

  useEffect(() => {
    // Fetch data from your API
    const fetchData = async () => {
      try {
        const response = await axios('http://localhost:3001/api/low-stock');
        console.error('fetching low stock data from bufferaccumulation :', response);
        // Assuming your API response has a 'results' property containing the rows
        setData(response.data || []); // Change response.results to response.data
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);  

  return (
    <div className="Low" style={styles.container}>
      <div className="header">
        <h3>Low Quantity Stock</h3>
        <button>See All</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Remaining Quantity</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.storename}</td>
              <td>
                <span style={{ fontWeight: 'bold' }}>
                  {item.inventorycount}
                </span> Packet
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const styles = {
  container: {
    bottom: '20px',
    right: '10px',
    border: '1px solid #ccc',
    padding: '10px',
    borderRadius: '3px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
};






















// -------------------------------------------------------------------------
// import * as React from "react";
// import { useState, useEffect } from "react";
// import axios from 'axios';
// import "./Lowqty.css";
// export default function BasicTable1() {
//   const [data, setData] = useState([]); // Rename rows to apiRows

//   useEffect(() => {
//     // Fetch data from your API
//     const fetchData = async () => {
//       try {
//         const response = await axios('http://localhost:3001/api/low-stock');
//         console.error('fetching low stock data from bufferaccumulation :', response);
//         // Assuming your API response has a 'results' property containing the rows
//         setData(response.data || []); // Change response.results to response.data
//       } catch (error) {
//         console.error("Error fetching data:", error);
//       }
//     };

//     fetchData();
//   }, []); // The empty dependency array ensures the effect runs only once, similar to componentDidMount


      


//   return (
//     <div className="Low" style={styles.container}>
//       <h3>Low Quantity Stock</h3>
//       <button>See All</button>
//       <ul>
//         <div className="low">
//         {data.map((item, index) => (
//           <li key={index}>
//             Store Name: {item.storename} <br />
//             <span style={{ fontWeight: 'bold' }}>Remaining Quantity: {item.inventorycount}</span> Packet
//           </li>
//         ))}
//         </div>
//       </ul>
//     </div>
//   );
// };

// const styles = {
//   container: {
//     bottom: '20px',
//     right: '10px',
//     border: '1px solid #ccc',
//     padding: '10px',
//     borderRadius: '3px',
//     boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
//   },
// };
  