import * as React from "react";
import { useState, useEffect } from "react";
import axios from 'axios';
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import "./Table.css";






const makeStyle=(status)=>{
  if(status === 'Approved')
  {
    return {
      background: 'rgb(145 254 159 / 47%)',
      color: 'green',
    }
  }
  else if(status === 'Pending')
  {
    return{
      background: '#ffadad8f',
      color: 'red',
    }
  }
  else{
    return{
      background: '#59bfff',
      color: 'white',
    }
  }
}

export default function BasicTable() {
    const [apiRows, setApiRows] = useState([]); // Rename rows to apiRows
    useEffect(() => {
      // Fetch data from your API
      const fetchData = async () => {
        try {
          const response = await axios('http://localhost:3001/api/data');
          console.error('fetching data from inventory :', response);
          // Assuming your API response has a 'results' property containing the rows
          setApiRows(response.data.results || []); // Change response.results to response.data.results
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      };
  
      fetchData();
    }, []); // The empty dependency array ensures the effect runs only once, similar to componentDidMount
  return (
      <div className="Table"><br />
      <h3>Top Selling Stock</h3>
        <TableContainer
          component={Paper}
          style={{ boxShadow: "0px 13px 20px 0px #80808029" }}
        >
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell align="left">Sold Quantity</TableCell>
                <TableCell align="left">Remaining Quantity</TableCell>
                <TableCell align="left">Price</TableCell>
              </TableRow>
            </TableHead>
            <TableBody style={{ color: "white" }}>
              {apiRows.map((apiRows,index) => (
                <TableRow
                  key={index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  
                  <TableCell align="left">{apiRows.storeid}</TableCell>
                  <TableCell align="left">{apiRows.productskuid}</TableCell>
                  <TableCell align="left">{apiRows.date}</TableCell>
        
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
  );
}
