import React from "react";
import Cards from "../Cards/Cards";
import Table from "../Table/Table";
import Table1 from "../Table/Lowqty";
import Table2 from  "../Table/Excessqty"
import Bar from "../Inventory/Bar";
import { Scrollbars } from 'react-custom-scrollbars';
import "./MainDash.css";
const MainDash = () => {
  return (
    <div className="MainDash">
      <Scrollbars style={{ width: 950, height: 600 }}>
      <Cards/>
      <Bar/>
      <Table/>

      </Scrollbars>
      
      
      
      
    </div>
  );
};

export default MainDash;
