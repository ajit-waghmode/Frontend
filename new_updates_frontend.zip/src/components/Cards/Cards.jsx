import React, { useState, useEffect } from 'react';
import "./Cards.css";
import axios from 'axios';
import { cardsData } from "../Data/Data";
import {
  UilUsdSquare,
  UilMoneyWithdrawal,
  UilClipboardAlt,
  UilYourSalesIcon,
  UilYourReturnIcon,
  UilYourTotalPurchaseIcon,
} from "@iconscout/react-unicons";
import Card from "../Card/Card";

const Cards = () => {
  const [apiData, setApiData] = useState({});
  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios('http://localhost:3001/api/sales');
        console.log("soldqty are ", result)
        setApiData(result.data.results[0]);
      } catch (error) {
        console.error('Error fetching data from API:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
    <h3>Sales Overview </h3>
    <div className="Cards">
      
      {cardsData.map((card, id) => {
        let cardValue;
        switch (card.title) {
          case 'Sales':
            cardValue = apiData.sum;
            break;
          case 'Purchase':
            cardValue = apiData.purchase;
            break;
          case 'Return':
            cardValue = apiData.return;
            break;
          default:
            cardValue = 0;
        }
        return (
          <div className="parentContainer" key={id}>
            <Card
              title={card.title}
              color={card.color}
              barValue={card.barValue}
              value={cardValue}
              png={card.png}
              series={card.series}
            />
            <br /><br />
          </div>
        );
      })}
    </div>
    </>
  );
};

export default Cards;
