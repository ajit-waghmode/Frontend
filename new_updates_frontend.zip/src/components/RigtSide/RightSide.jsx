import React from "react";
// import CustomerReview from "../CustomerReview/CustomerReview";
// import line from "../Inventory/Line";
// import Table from "../Table/Table";
import Updates from "../Updates/Updates";
import Low from "../Table/Lowqty";
import Excess from "../Table/Excessqty"
import { Scrollbars } from 'react-custom-scrollbars';
import Excessqty from "../Table/Excessqty";
import "./RightSide.css";


const RightSide = () => {
  return (
    <div className="RightSide">
     
      
        <Low />
        {/* <Excess /> */}
        {/* <Updates/> */}
      
       <Excessqty />  
       {/* <Excessqty />  */}
         


      {/* <div>
        <h3>Requests</h3>
        <Table />
        <CustomerReview />
        <Line /> 
      </div>  */}

      

    </div>
  );
};

export default RightSide;
